<?php 
    // tangkap request class_nilai.php
    require_once 'class_nilai.php';

    $ns1 = new NilaiSantri('Fulan',70);
    $ns2 = new NilaiSantri('Badu',69);
    $ns3 = new NilaiSantri('Usro',85);
    $ns4 = new NilaiSantri('Jarwo',40);
    $ar_santri = [$ns1,$ns2,$ns3,$ns4];
?>
<table border="1" style="width: 100%;">
    <thead>
        <tr>
            <th style="width: 5%;">No</th>
            <th style="width: 25%;">Nama</th>
            <th style="width: 10%;">Nilai</th>
            <th style="width: 20%;">Hasil</th>
        </tr>
    </thead>
    <tbody>
    <?php
        $nomor = 1;
        foreach ($ar_santri as $san) {
            echo '<tr>';
            echo '<td>' . $nomor . '</td>';
            echo '<td>' . $san->nama . '</td>';
            echo '<td>' . $san->nilai . '</td>';
            echo '<td>' . $san->gethasil() . '</td>';
            echo '</tr>';
            $nomor++;
        }
        ?>
    </tbody>
</table>